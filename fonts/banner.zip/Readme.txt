If you wish to use it commercially I ask for
a one-time US $10 paypal payment to anfa67@yahoo.co.uk